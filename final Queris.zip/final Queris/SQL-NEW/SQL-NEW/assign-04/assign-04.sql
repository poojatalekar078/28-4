CREATE TABLE Vendors (
Vendor_ID INT NOT NULL  PRIMARY KEY,
Account_number VARCHAR(15),
Company_name VARCHAR(50) NOT NULL,
Location VARCHAR(50) NOT NULL, 
Credit_Rating TINYINT NOT NULL
CHECK(Credit_Rating >=1 AND Credit_Rating <=5),
Active_Flag BIT, 
Purchasing_web_service_url VARCHAR(255)); 

SELECT *FROM Vendors;

CREATE TABLE Product_Inventorys(
Product_inventory_Id INT NOT NULL PRIMARY KEY,
Product_Id VARCHAR(15), 
Product_Name VARCHAR(50) NOT NULL,
Location VARCHAR(50) NOT NULL, 
Quantity INT, 
Unit_price DECIMAL(9,2));

SELECT *FROM Product_Inventorys;

CREATE TABLE Sales ( 
Sales_ID INT NOT NULL PRIMARY KEY,
Product_ID INT FOREIGN KEY REFERENCES Product_inventorys(Product_inventory_ID), 
Vendor_ID INT FOREIGN  KEY REFERENCES Vendors(Vendor_ID),
Sales_date DATETIME, 
Quantity INT); 


SELECT *FROM Sales;


 INSERT INTO Vendors VALUES
(1,'AC100','Tech Solutions','Delhi',3,1,'https://xyz.com'), 
(2,'AC102','National Sales Corp','Mysuru',5,1,'https://xyz1.com'), 
(3,'AC103','Tech Innovations','Bangalore',2,1,'https://xyz2.com'), 
(4,'AC104','Metro Electronics','Kolkata',4,1,'https://xyz3.com'), 
(5,'AC105','ABC Suppliers','Chennai',1,1,'https://xyz4.com'),
(6,'AC106','International Merchandise','Bengaluru',3,1,'https://abc1.com'), 
(7,'AC107','Stock Exchange','Dehli',2,1,'https://abc3.com'), 
(8,'AC108','ABC Constructions','Pune',1,1,'https://abc4.com'), 
(9,'AC109','Machine Mechanics','Bengaluru',4,1,'https://abc8.com'), 
(10,'AC1007','Global Imports','Mysuru',3,1,'https://abc6.com'); 



INSERT INTO Product_inventorys(Product_inventory_ID, Product_ID, Product_Name, Location, Quantity, Unit_price) VALUES
(1, '101', 'Orange', 'Mysuru', 10, 600), 
(2, '102', 'Tablet', 'Bengaluru', 5, 2000), 
(3, '103', 'Desktop', 'Bombay', 5, 2000), 
(4, '104', 'Earphones', 'Dehli', 10, 200), 
(5, '105', 'Scooter', 'Pune', 1, 5000), 
(6, '106', 'Chair', 'Dehli', 2, 2000), 
(7, '107', 'Truck', 'Mysuru', 20, 5000), 
(8, '108', 'Lathe Machine', 'Bengaluru', 10, 700), 
(9, '109', 'Drone', 'Bombay', 30, 500), 
(10, '110', 'Notebook', 'Mysuru', 50, 1000);

INSERT INTO Sales (Sales_id, Product_id,Vendor_id,Sales_date,Quantity) VALUES
(1,1,1,'2011-09-01', 10), 
(2,2,2,'2011-08-01', 5), 
(3,4,2,'2011-09-01', 10), 
(4,7,5,'2011-09-01', 10), 
(5,3,9,'2011-09-01', 10), 
(6,5,1,'2011-09-01', 10), 
(7,6,3,'2011-09-01', 10), 
(8,9,2,'2011-09-01', 10), 
(9,10,7,'2011-09-01', 10), 
(10,2,4,'2011-09-01', 10),
(11,10,7,'2011-09-01', 10),
(13,10,10,'2011-07-01', 10),
(14,10,10,'2011-07-01', 10),
(17,9,6,'2011-07-01', 11),
(19,9,6,'2011-08-01', 11),
(18,9,6,'2011-08-01', 12);

SELECT *FROM Sales;


----1
SELECT * FROM Vendors;

--2
SELECT 
    P.Product_name,
    S.Sales_date
FROM 
    Product_inventorys AS P
INNER JOIN 
    Sales AS S ON P.Product_inventory_ID = S.Product_ID 
INNER JOIN 
    Vendors AS V ON S.Vendor_ID = V.Vendor_ID
WHERE 
    S.Sales_date = '2011-09-01' 
    AND V.Company_name = 'National Sales Corp'; 

	SELECT *FROM Vendors;
	SELECT *FROM Sales;
	SELECT *FROM Product_Inventorys;

	--3
SELECT 
COUNT(*) AS "count of Products"
FROM 
Sales AS S
INNER JOIN 
           Vendors AS V ON S.Vendor_ID = V.Vendor_ID
INNER JOIN 
         Product_inventorys AS P
         ON S.Product_ID = P.Product_inventory_ID
WHERE 
   V.Company_name = 'International Merchandise'
    AND S.Sales_date = '2011-08-01';
   

	SELECT *FROM Vendors;
	SELECT *FROM Sales;
	SELECT *FROM Product_Inventorys;


--4
SELECT Vendor_ID AS "Vendors", SUM(Product_ID) AS "Total_Quantity_Sold"
FROM Sales
GROUP BY Vendor_ID
HAVING SUM(Product_ID) > (SELECT AVG(Product_ID) FROM Sales);


SELECT *FROM Sales;
SELECT *FROM Vendors;
SELECT *FROM Sales;

--5
	CREATE TABLE Another_Table (
    ProductName VARCHAR(255),
    CompanyName VARCHAR(255),
    SalesDate DATE
);
INSERT INTO Another_Table (ProductName, CompanyName, SalesDate)
SELECT 
    P.Product_Name,
    V.Company_Name,
    S.Sales_date
FROM 
    Sales S
JOIN 
    Vendors V ON S.Vendor_ID = V.Vendor_ID
JOIN 
    Product_inventorys P ON S.Product_ID = P.Product_inventory_ID;


SELECT*FROM Another_Table;

select *from Vendors;
SELECT *FROM Sales;
SELECT *FROM Product_Inventorys;



---6
SELECT AVG(Unit_price) AS "Average Unit Price"
FROM Product_Inventorys
WHERE Location = 'Mysuru';


--7
SELECT
 MIN(Unit_Price) AS "Minimum Unit price",
MAX(Unit_Price) AS "Maximum Unit price"
FROM Product_Inventorys
WHERE Location = 'Mysuru';

SELECT *FROM Product_Inventorys;
--8
ALTER TABLE Sales ADD Shipped BIT;
SELECT * FROM Sales;

--9

UPDATE Sales
SET Shipped = 1
WHERE Sales_Date < GETDATE();


SELECT *FROM Sales;

---10


DELETE FROM Vendors
WHERE Vendor_ID NOT IN (
  SELECT Vendor_ID FROM Sales 
  UNION
  SELECT Vendor_ID FROM Vendors);


SELECT *FROM Vendors;
SELECT *FROM Sales;


SELECT *FROM Vendors;
SELECT *FROM Sales;
---11
ALTER TABLE Vendors DROP COLUMN Purchasing_Web_service_url;

SELECT *FROM Vendors;


----12
ALTER TABLE Vendors ALTER COLUMN Location VARCHAR(255);
SELECT *FROM Vendors;

--13

SELECT P.Product_Name, V.Company_Name FROM Sales S  
 INNER JOIN Product_inventorys P 
ON S.Product_ID = P.Product_inventory_ID
 INNER JOIN Vendors V ON S.Vendor_ID = V.Vendor_ID 
WHERE P.LOCATION = 'Mysuru' AND  V.LOCATION = 'Mysuru';


SELECT *FROM Product_Inventorys;
SELECT *FROM Vendors;
SELECT *FROM Sales;

--SP
---1
SELECT ProductName,CompanyName,SalesDate
FROM Another_Table
ORDER BY SalesDate DESC;

---2
CREATE PROCEDURE  Insert_Sales

    @Sales_ID INT,
    @Vendor_ID INT,
    @Product_ID INT,
    @Quantity INT,
    @SaleDate DATETIME
AS
BEGIN
    INSERT INTO sales (Sales_ID, Vendor_ID, Product_ID, Quantity, Sales_date)
    VALUES (@Sales_ID, @Vendor_ID, @Product_ID, @Quantity, @SaleDate);
END;


EXEC Insert_Sales
    @Sales_ID = 21,
    @Vendor_ID = 7, 
    @Product_ID = 10, 
    @Quantity = 20, 
    @SaleDate = '2001-12-31';

	SELECT *FROM Sales;
--3
CREATE PROCEDURE UpdateProduct_Inventory
    @ProductInventoryID INT,
    @ProductID VARCHAR(15),
    @Quantity INT,
    @UnitPrice DECIMAL(9, 2)
AS
BEGIN
    UPDATE Product_Inventorys
    SET Product_ID = @ProductID,
        Quantity = @Quantity,
        Unit_price = @UnitPrice
    WHERE Product_inventory_ID = @ProductInventoryID;
END;

EXEC UpdateProduct_Inventory @ProductInventoryID = 1, @ProductID = '120', @Quantity = 15, @UnitPrice = 700;

SELECT *FROM Product_Inventorys;

--4
CREATE PROCEDURE Update_Credit_Rating 
AS 
BEGIN 
    DECLARE @MaxSalesVendor_ID INT 
    
    SELECT  @MaxSalesVendor_ID= vendor_ID 
    FROM sales 
    WHERE YEAR(sales_date) = 2011 AND MONTH(sales_date) = 8 
    ORDER BY Quantity DESC 
    
    DECLARE @Total_Quantity INT 
    SELECT @Total_quantity = SUM(quantity) 
    FROM sales 
    WHERE vendor_ID = @MaxSalesVendor_ID
    
    IF @total_quantity > 10000 
        UPDATE Vendors SET Credit_Rating = 1 WHERE Vendor_ID = @MaxSalesVendor_ID; 
    ELSE IF @Total_quantity > 5000 
        UPDATE Vendors SET Credit_Rating = 2 WHERE Vendor_ID = @MaxSalesVendor_ID; 
    ELSE IF @total_quantity > 1000 
        UPDATE Vendors SET Credit_Rating = 3 WHERE Vendor_ID = @MaxSalesVendor_ID; 
    ELSE IF @total_quantity > 500 
        UPDATE Vendors SET Credit_Rating = 4 WHERE Vendor_ID= @MaxSalesVendor_ID; 
    ELSE 
        UPDATE Vendors SET Credit_Rating = 5 WHERE Vendor_ID = @MaxSalesVendor_ID; 
END;



EXEC update_Credit_Rating;
SELECT *FROM Vendors;


















