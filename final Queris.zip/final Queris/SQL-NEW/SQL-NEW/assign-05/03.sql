USE ASSIGN;
CREATE TABLE Artists( Artist_ID INT PRIMARY KEY, A_Name VARCHAR(255) ); 
INSERT INTO Artists(Artist_ID, A_Name) VALUES 
(1, 'Mogwai'),  
(2, 'Nirvana'), 
(3, 'Explosions in the Sky'),  
(4, 'Godspeed You! Black Emperor'), 
(5, 'This Will Destroy You'),  
(6, 'Russian Circles'), 
(7, 'Saxon Shore'),  
(8, 'If These Trees Could Talk'), 
(9, 'Maybeshewill'),  
(10, 'Yndi Halda'), 
(11, 'Tristeza'),  
(12, 'Pelican'), 
(13, 'Grails'),  
(14, 'The Album Leaf'), 
(15, 'Oh Hiroshima'),  
(16, 'Sigur Ros');
SELECT *FROM Artists;


CREATE TABLE SimilarArtists( Artist_ID INT FOREIGN KEY REFERENCES Artists(Artist_ID), SimArtist_ID INT, Weight INT ); 
INSERT INTO SimilarArtists(Artist_ID, SimArtist_ID, Weight)  VALUES 
(1,1,50), (2,2,60), (3,3,70), 
(4,4,80), (5,1,90), (6,5,50), 
(7,3,60), (8,7,80), (9,4,110), 
(10,9,30), (11,10,10), (12,11,70), 
(13,12,90), (14,11,120), (15,13,150), (16,14,130); 
SELECT *FROM SimilarArtists;



CREATE TABLE Albums( Album_ID INT PRIMARY KEY, Artist_ID INT FOREIGN KEY REFERENCES Artists(Artist_ID), Album_Name varchar(255) ); 
INSERT INTO Albums(Album_ID, Artist_ID, Album_Name) VALUES 
(1, 1, 'All of a Sudden I Miss Everyone'),  
(2, 2, 'Red Forest'),  
(3, 3, 'Explosions in the Sky'),  
(4, 4, 'Takk...'),  
(5, 5, 'Abbey Road'),  
(6, 6, 'In a Safe Place'),  
(7, 7, 'The Earth is Not a Cold Dead Place'),  
(8, 8, 'The Dark Side of the Moon'),  
(9, 9, 'AM'),  
(10, 10, 'Let It Bleed'),  
(11, 11, 'Come On Die Young'),  
(12, 12, 'In Utero'),  
(13, 13, 'Lost in the Trees'),  
(14, 14, 'Ten'),  
(15, 15, 'The Joshua Tree');

SELECT *FROM Albums;


CREATE TABLE Tracks( Track_ID INT PRIMARY KEY, Artist_ID INT FOREIGN KEY REFERENCES Artists(Artist_ID), Track_Name VARCHAR(255), T_Length INT );

INSERT INTO Tracks(Track_ID, Artist_ID, Track_Name, T_Length) VALUES 
(1,1,'Intro',800000), (2,2,'Intro',400000), 
(3,3,'Track',600000), (4,1,'Why Track',800000), 
(5,2,'The Track',600000), (6,4,'Track1',800000), 
(7,5,'Why Track',600000), (8,6,'Intro',600000), 
(9,7,'The Track',700000), (10,8,'Track2',9000000), 
(11,9,'Why Track',800000), (12,10,'Track3',600000), 
(13,8,'Track4',100000), (14,9,'The Track',900000), 
(15,9,'Track5',4000000), (16,10,'Why Track',300000); 
SELECT *FROM Tracks;


CREATE TABLE TrackLists( Album_ID INT FOREIGN KEY REFERENCES Albums(Album_ID), Track_ID INT FOREIGN KEY REFERENCES Tracks(Track_ID), Track_Num INT ); 
INSERT INTO TrackLists(Album_ID, Track_ID, Track_Num) VALUES 
(1, 15, 1),  
(1, 15, 2),
(1, 3, 3), 
(2, 4, 4),  
(2, 5, 5),  
(3, 15, 6),  
(3, 7, 7), 
(4, 8, 1),  
(4, 9, 2),  
(5, 10, 5), 
(5, 11, 4),  
(6, 12, 3), 
(6, 13, 2), 
(7, 14, 6),  
(8, 7, 7),  
(9, 8, 1),  
(10, 9, 2),
(7, 10, 5),
(6, 11, 4), 
(8, 12, 3), 
(11, 15, 2); 
SELECT *FROM TrackLists;

--1
SELECT Track_Name
FROM Tracks
WHERE T_Length > 600000;
SELECT *FROM Tracks;
--2
SELECT A.A_Name
FROM Artists AS A
INNER JOIN Albums AL ON A.Artist_ID = AL.Artist_ID
WHERE AL.Album_Name = A.A_Name;

SELECT *FROM Artists;
SELECT *FROM Albums;

--3

SELECT  A.A_Name
FROM Albums AS  AL
INNER JOIN Tracks T ON AL.Artist_ID = T.Artist_ID
INNER JOIN Artists AS A ON Al.Artist_ID = A.Artist_ID
WHERE T.Track_Name = 'Intro'
GROUP BY A.A_Name;

SELECT *FROM Albums;
SELECT *FROM Artists;
SELECT *FROM Tracks;


--4




SELECT S.SimArtist_Id, A1.A_Name FROM   
SimilarArtists S  
JOIN Artists  A ON S.Artist_id = A.Artist_Id  
LEFT JOIN Artists A1 ON S.SimArtist_Id = A1.Artist_Id  
WHERE A.A_Name = 'Mogwai' OR A.A_Name = 'Nirvana'  
AND S.weight > (SELECT MAX(weight) FROM SimilarArtists WHERE Artist_Id = (SELECT Artist_Id FROM Artists WHERE A_Name = 'Nirvana')); 

SELECT *FROM Artists;
SELECT *FROM SimilarArtists;

--5
SELECT A.Album_Name
FROM Albums AS A
INNER JOIN TrackLists TL ON A.Album_ID = TL.Album_ID
INNER JOIN Tracks T ON TL.Track_ID = T.Track_ID
GROUP BY A.Album_Name
HAVING COUNT(TL.Track_ID) > 30;


SELECT *FROM Albums;
SELECT *FROM TrackLists;
SELECT *FROM Tracks;
--6


SELECT A.A_Name 
FROM Artists AS A 
INNER JOIN 
SimilarArtists AS  S  ON
 S.Artist_ID = A.Artist_Id  and S.weight > 5;

SELECT *FROM Artists;
SELECT *FROM SimilarArtists;

 

 --7
SELECT A.Album_Name, T.Track_Name
FROM Albums A
LEFT JOIN TrackLists TL ON A.Album_ID = TL.Album_ID AND TL.Track_Num = 15
LEFT JOIN Tracks T ON TL.Track_ID = T.Track_ID;


--8

SELECT A.A_Name, AVG(T.T_Length) AS AvgLength FROM Artists A
INNER JOIN Tracks AS T ON T.Artist_Id = A.Artist_Id 
INNER JOIN Albums AL ON A.Artist_Id = AL.Artist_Id  
INNER JOIN TrackLists TL ON TL.Album_Id = AL.Album_Id 
GROUP BY A.A_Name, AL.Album_Name 
ORDER BY AvgLength DESC; 

--9


SELECT *FROM Albums;
SELECT *FROM TrackLists;
SELECT *FROM Tracks;
SELECT *FROM SimilarArtists;
SELECT *FROM Albums;
SELECT *FROM Tracks;
SELECT *FROM TrackLists;
SELECT *FROM Artists;