

CREATE TABLE Models( M_Id INT PRIMARY KEY, M_Name VARCHAR(255), M_Model VARCHAR(255)); 

CREATE TABLE Cars( Car_Id INT PRIMARY KEY, M_Id INT FOREIGN KEY(M_ID) REFERENCES Models(M_Id), C_Year INT );

CREATE TABLE Buyers( B_Id INT PRIMARY KEY, B_Name VARCHAR(50), B_City VARCHAR(255), Age INT ); 

CREATE TABLE Manufacturers( M_Name VARCHAR(255) PRIMARY KEY, Location VARCHAR(255) );

CREATE TABLE Salespersons( S_Id INT PRIMARY KEY, S_Name VARCHAR(255), Years_Employeed INT );

CREATE TABLE Transactions( B_Id INT FOREIGN KEY REFERENCES Buyers(B_Id), Car_Id INT FOREIGN KEY REFERENCES
Cars(Car_Id), S_Id INT FOREIGN KEY REFERENCES Salespersons(S_Id), Amount DECIMAL(10,2), T_Month INT, 
T_Day INT, T_Year INT ); 





SELECT * FROM Cars; 
SELECT *FROM Models;
SELECT *FROM Buyers;
SELECT *FROM  Manufacturers;
SELECT *FROM Salespersons;
SELECT * FROM Transactions; 



INSERT INTO Cars(Car_Id, M_Id, C_Year) VALUES 
(1,1,1997), 

(2,2,1997), 

(3,2,1998), 

(4,4,1999), 

(5,5,2000); 


INSERT INTO Models(M_Id, M_Name, M_Model)  

VALUES (1,'Ford','mustang'), 

(2,'Toyota','innova'), 

(3,'BMW','city'), 

(4,'Lamborghini','esxl'), 

(5,'Mercedes-Benz','punch'); 


INSERT INTO Buyers(B_Id, B_Name, B_City, Age) VALUES 

(1,'Pooja','Mysuru',22), 

(2,'Poonam','Karwar',54), 

(3,'Ramesh','Pune',29), 

(4,'Pallavi','Mysuru',19), 

(5,'jack','Bombay',22);

INSERT INTO Manufacturers(M_Name, Location) VALUES  

('Ford','Bengaluru'), 

('Toyota','Mysuru'), 

('BMW','Dehli'), 

('Lamborghini','Mysuru'), 

('Mercedes-Benz','Bengaluru');



INSERT INTO Salespersons(S_Id, S_Name, Years_Employeed) VALUES 

(1, 'john',10), 

(2, 'wick',5), 

(3, 'ram',7), 

(4, 'mohan',2), 

(5, 'abhi',12); 



INSERT INTO Transactions(B_Id, Car_Id, S_Id, Amount, T_Month, T_Day, T_Year) values 

(1,1,1,9000,2,2,1997), 

(1,1,1,9000,2,2,1997), 

(2,2,2,10000,1,1,1997), 

(3,2,3,8000,1,3,1998), 

(4,5,5,5000,22,12,1997), 

(5,4,4,9000,6,22,2000);





SELECT * FROM Cars; 
SELECT *FROM Models;
SELECT *FROM Buyers;
SELECT *FROM  Manufacturers;
SELECT *FROM Salespersons;
SELECT * FROM Transactions; 


--1
SELECT B.B_Name, B.B_City FROM Buyers B
INNER JOIN Transactions  AS T 
ON T.B_Id = B.B_Id 
INNER JOIN Cars  AS C 
ON T.Car_Id = C.Car_Id 
INNER JOIN Models AS MO
ON MO.M_Id = C.M_Id 
INNER JOIN Manufacturers M ON
M.M_Name = Mo.M_Name 
WHERE M.M_Name = 'Ford' AND Mo.M_Model = 'mustang' AND T.Amount < 10000; 

SELECT *FROM Buyers;
SELECT *FROM Manufacturers;
SELECT *FROM Cars;
SELECT *FROM  Models;
SELECT *FROM Transactions;

--2

SELECT  S_Id  
FROM Transactions T
INNER JOIN Cars C ON T.Car_Id = C.Car_Id  
INNER JOIN Models Mo ON C.M_Id = Mo.M_Id  
INNER JOIN Manufacturers M ON MO.M_Name = M.M_Name  
WHERE (M.M_Name = 'Ford' OR M.M_Name = 'Toyota') AND T.T_Year = 1997  
GROUP BY S_Id;

SELECT *FROM Transactions;
SELECT *FROM Cars;
SELECT *FROM Models;
SELECT *FROM Manufacturers;
--3

SELECT DISTINCT S_Id  

FROM Transactions  AS T

INNER JOIN Cars AS C ON T.Car_Id = C.Car_Id  

INNER JOIN Models AS Mo ON C.M_Id = Mo.M_Id  

INNER JOIN Manufacturers AS M ON Mo.M_Name = M.M_Name; 



SELECT *FROM Transactions;
SELECT *FROM Cars;
SELECT *FROM Models;
SELECT *FROM Manufacturers;



---4
SELECT S_Name
FROM Salespersons
WHERE S_Id NOT IN (
    SELECT  S_Id
    FROM Transactions
    WHERE T_Year = 1997
);



---5
SELECT S_Name, SUM(Amount) AS "Total Sales Amount"
FROM Salespersons
INNER JOIN Transactions ON Salespersons.S_Id = Transactions.S_Id
WHERE T_Year = 1997
GROUP BY  S_Name
ORDER BY "Total Sales Amount" DESC

SELECT *FROM SALES;
SELECT *FROM Transactions;



--6






SELECT S_Name, AVG(Amount) AS "Avg Sales Amount"
FROM Salespersons
JOIN Transactions ON Salespersons.S_Id = Transactions.S_Id
WHERE Years_Employeed < 10
GROUP BY S_Name
HAVING COUNT(*) > 50
ORDER BY "Avg Sales Amount" DESC;

SELECT * FROM Cars; 
SELECT *FROM Models;
SELECT *FROM Buyers;
SELECT *FROM  Manufacturers;
SELECT *FROM Salespersons;
SELECT * FROM Transactions; 