USE ASSIGN;

CREATE TABLE Employess( F_Name VARCHAR(255), M_Name VARCHAR(255), L_Name VARCHAR(255), 
SSN INT PRIMARY KEY, B_Date DATE, E_Address VARCHAR(255), Sex CHAR(20), 
Salary DECIMAL(10,2), Super_Ssn VARCHAR(255), DNo INT ); 
SELECT *FROM Employess;
INSERT INTO Employess(F_Name ,M_Name ,L_Name , SSN, B_Date, E_Address, Sex, Salary, Super_Ssn, DNo) VALUES 
('Rob','D','Smith','1234','2000-01-01','Bengaluru','M',30000,'2345',2), 
('john','A','rob','1235','2001-11-01','Mysuru','M',35000,'2346',3), 
('Ram','K','K','1236','2001-01-05','Karwar','M',20000,'2347',5), 
('alise','C','Pop','1237','2000-12-29','Pune','F',16800,'2348',3), 
('Pooja','S','Talekar','1238','2002-08-11','Mysuru','F',42400,'2349',1), 
('Spider','M','Man','1239','2003-11-12','Bengaluru','M',60000,'2350',4);  


CREATE TABLE Departmentts( D_Name VARCHAR(255), D_Number INT PRIMARY KEY, 
Mgr_Ssn INT FOREIGN KEY REFERENCES Employess(SSN), Mgr_Start_Date DATE ); 
select *from Departmentts;
INSERT INTO Departmentts(D_Name, D_Number, Mgr_Ssn, Mgr_Start_Date) VALUES
('Research',2,'1234','2000-01-01'), 
('Technology',1,'1235','2001-01-01'), 
('Chemistry',3,'1236','2002-04-11'), 
('Electrical',6,'1237','2000-01-01'), 
('Administartion',4,'1238','2000-01-01'), 
('Research',5,'1239','2000-01-01'); 

CREATE TABLE Dependent( ESsn INT REFERENCES Employess(Ssn), Dependent_Name VARCHAR(255) PRIMARY KEY, 
Sex CHAR(2), BDate date,Relationship VARCHAR(255) ); 
INSERT INTO Dependent(ESsn, Dependent_Name, Sex, BDate, Relationship)  VALUES 
('1234', 'Emma Smith', 'F', '1995-03-10', 'Child'),  
('1235', 'James Johnson', 'M', '1996-05-13', 'Child'),  
('1236', 'Sophia Williams', 'F', '2000-06-05', 'Parent'),  
('1237', 'Daniel Brown', 'M', '2001-07-25', 'Child'),  
('1238', 'Olivia Miller', 'F', '1999-09-05', 'Child'),  
('1235', 'Alexander Taylor', 'M', '1998-04-01', 'Brother'),  
('1234', 'Charlotte Anderson', 'F', '2002-11-15', 'Sister'); 
SELECT *FROM Dependent;


CREATE TABLE Dept_Location( D_Number INT FOREIGN KEY REFERENCES Departmentts(D_Number), D_Location VARCHAR(255) PRIMARY KEY ); 
SELECT *FROM Dept_Location;
INSERT INTO Dept_Location(D_Number, D_Location) VALUES 
(1,'Bengaluru'), 
(2,'Karwar'), 
(3,'Goa'), 
(4,'Manglore'), 
(5,'Moodbidre'), 



CREATE TABLE Projects( P_Name VARCHAR(255) , P_Number INT PRIMARY KEY, P_Location VARCHAR(255), 
D_Num INT FOREIGN KEY REFERENCES Departmentts(D_Number) ); 
INSERT INTO Projects(P_Name, P_Number, P_Location, D_Num) VALUES 
('project 1', 1, 'Stafford', 5),  
('project 2', 2, 'Bengaluru', 4),  
('project 3', 3, 'Karwar', 1),  
('project 4', 4, 'Goa', 5), 
('project 5', 5, 'Mangluru', 5), 
('project 6', 6, 'Moodbidre', 5); 
SELECT *FROM Projects;



CREATE TABLE WorksOns( ESsn INT FOREIGN KEY REFERENCES Employess(SSN), P_Num INT FOREIGN KEY REFERENCES Projects(P_Number), Hours DECIMAL(4,2) ); 

 INSERT INTO WorksOns(ESsn, P_Num, Hours)  VALUES
 ('1234',1,30), 
('1235',2,15), 
('1236',3,50), 
('1234',2,20), 
('1237',1,35), 
('1238',4,40), 
('1234',5,20), 
('1237',3,35), 
('1238',1,40);
SELECT *FROM WorksOns;



----1


SELECT E.F_Name, E.L_Name, E.E_Address
FROM Employess AS E
INNER JOIN Departmentts AS D ON E.DNo = D.D_Number
WHERE D.D_Name = 'Research';

SELECT *FROM Employess;
SELECT *FROM Departmentts;
--2

SELECT 
P.P_Number AS "Project Number",
D.D_Number AS "Controlling Department Number",
E.L_Name AS "Department Manager LastName",
E.E_Address AS "Department Manager Address",
E.B_Date AS "Department Manager Birthdate"
FROM 
Projects AS P
INNER JOIN 
Departmentts  AS D
ON P.D_Num =D.D_Number
INNER JOIN 
Employess AS E
ON D.Mgr_Ssn = E.SSN
WHERE 
P.P_Location = 'Stafford';

    SELECT *FROM Projects;
	SELECT *FROM Departmentts;
	SELECT *FROM Employess;

 --3

SELECT DISTINCT E.F_Name , E.L_Name 
FROM Employess E

INNER JOIN WorksOns  W ON W.ESsn = E.SSN 

INNER JOIN Projects AS P ON P.P_Number = W.P_Num 

WHERE P.D_Num = 5; 



SELECT *FROM Projects;
SELECT *FROM WorksOns;
SELECT *FROM Employess

--4


SELECT P.P_Number
FROM Projects AS P
JOIN Departmentts AS D ON P.D_Num = D.D_Number
JOIN Employess AS E ON D.Mgr_Ssn = E.SSN 
OR E.SSN IN (SELECT ESsn FROM WorksOns AS W WHERE W.P_Num = P.P_Number)
WHERE E.L_Name = 'Smith'
GROUP BY P.P_Number;



SELECT *FROM Departmentts;
SELECT *FROM Employess;
SELECT *FROM WorksOns;
SELECT *FROM Projects;
---5

SELECT 
    E.F_Name,
    E.L_Name
FROM 
    Employess E
WHERE 
    ( SELECT  COUNT(Dependent_Name) FROM  Dependent D WHERE 
            D.ESsn = E.SSN) >= 2;

SELECT *FROM Dependent;
--6
SELECT F_Name, L_Name
FROM Employess
WHERE SSN NOT IN (SELECT ESsn FROM Dependent);

SELECT *FROM Employess;
SELECT *FROM Dependent;


--7
SELECT E.F_Name, E.M_Name, E.L_Name
FROM Employess E
INNER JOIN Departmentts D ON E.SSN = D.Mgr_Ssn
INNER JOIN Dependent DE ON E.SSN = DE.ESsn
GROUP BY E.SSN, E.F_Name, E.M_Name, E.L_Name
HAVING COUNT(DE.Dependent_Name) >= 1;

SELECT *FROM Employess;
select *from Departmentts;
SELECT *FROM Projects;
select *from Dept_Location;
SELECT *FROM Dependent;
SELECT *FROM WorksOns;