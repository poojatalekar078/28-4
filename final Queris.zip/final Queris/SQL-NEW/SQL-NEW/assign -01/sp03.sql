--3
CREATE PROCEDURE New_Depart
@DeptCode VARCHAR(10), @DeptName VARCHAR(255),@DeptLocation VARCHAR(255),@Status BIT
AS
BEGIN
INSERT INTO Department_Masters
(Department_Code,Department_Name,Department_Location,Department_Status)values
(@DeptCode,@DeptName,@DeptLocation,@Status);
END;

EXEC New_Depart  'Test','Testing','hebbal',1; 

SELECT *FROM Department_Masters;


--4
CREATE PROCEDURE New_Employees
@FirstName VARCHAR(50),@LastName VARCHAR(50), @Mail_ID VARCHAR(100),@ReportingTo INT,@Department_Code INT,
@Phone VARCHAR(50),@Mobile_Number VARCHAR(50),@Employed_Country 
VARCHAR(50),@Dateofjoining DATETIME, @City VARCHAR(50),@Salary NUMERIC(10,2)
AS
BEGIN
INSERT INTO Employee_Details
(FirstName,LastName,Mail_ID,ReportingTo,Department_Code,Phone,Mobile_Number,
Employed_Country,Dateofjoining,City,Salary)VALUES ( @FirstName ,@LastName,@Mail_ID,@ReportingTo,@Department_Code,@Phone,@Mobile_Number,@Employed_Country,@Dateofjoining , @City,
@Salary );
END;


EXEC  New_Employees 'Pooja','Talekar','talekarpo@gmail.com', 2,3,8431474349,7483483484,'India','06-05-2000','karwar',90000;


SELECT *FROM Employee_Details;

--5

 
CREATE PROCEDURE Update_New_Employees  
@Staff_ID INT, @FirstName VARCHAR(50), @LastName VARCHAR(50),@Mail_ID VARCHAR(100), @ReportingTo INT,  
@Department_Code INT, @Phone VARCHAR(50), @Mobile_Number VARCHAR(50), @Employed_Country VARCHAR(50),
@Dateofjoining DATETIME, @City VARCHAR(50),  @Salary NUMERIC(10,2)
AS
UPDATE Employee_details SET FirstName=@FirstName, LastName=@lastname, Mail_ID=@Mail_ID,
Reportingto=@ReportingTo, Department_Code=@Department_Code,Phone=@Phone, 
Mobile_Number=@Mobile_Number, Employed_Country=@Employed_Country, Dateofjoining=@Dateofjoining, 
City=@City, Salary=@Salary  WHERE Staff_ID = @Staff_ID;  


 EXEC   Update_New_Employees 6,'Punnu','Talekar','talekarpo@gmail.com', 2,3,8431474349,7483483484,'India','06-05-2000','karwar',90000;

 SELECT *FROM Employee_Details;


 --6
CREATE PROCEDURE Employe
AS 
SELECT FirstName AS "Employee Name",
DATEDIFF(YEAR, Dateofjoining, GETDATE())
AS "Years of experience"
FROM Employee_details;

EXEC Employe;

