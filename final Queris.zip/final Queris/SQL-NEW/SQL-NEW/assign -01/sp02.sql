CREATE PROCEDURE Departments
AS
BEGIN
SELECT *FROM Department_Masters;
END;

EXEC Departments;