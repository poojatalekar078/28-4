USE ASSIGN;
CREATE TABLE Department_Masters
(Department_ID INT IDENTITY(1,1) PRIMARY KEY, 
Department_Code VARCHAR(10),
Department_Name VARCHAR(255),
Department_Location VARCHAR(255),
Department_Status BIT);

SELECT *FROM Department_Masters;


INSERT INTO Department_Masters
(Department_Code,Department_Name,Department_Location,Department_Status )
VALUES('IT','Information Tech','Mysore',1),
('MAR','Marketing','Mysore',1),
('HR','Human Resource','Mysore',1),
('DEV','Development','Mysore',1);


CREATE TABLE Employee_Details(Staff_ID INT IDENTITY(1,1) PRIMARY KEY,FirstName VARCHAR(50),LastName VARCHAR(50),Mail_ID VARCHAR(100),
ReportingTo INT,Department_Code INT ,Phone VARCHAR(50),Mobile_Number VARCHAR(50),Employed_Country VARCHAR(50),DateofBirth DATETIME,
Dateofjoining DATETIME,City VARCHAR(50),Salary NUMERIC(10,2) FOREIGN KEY(Department_Code) REFERENCES Department_Masters(Department_ID));

SELECT *FROM Employee_Details;

INSERT INTO Employee_Details
(FirstName,LastName,Mail_ID,ReportingTo,Department_Code,Phone,Mobile_Number,
Employed_Country,DateofBirth,Dateofjoining,City,Salary) VALUES
('Abishek', 'Kumar', 'abhishek@example.com', 1, 1, '1234567890', '9876543210', 'India', '1990-01-01', '2010-01-01', 'Mysore', 80000.00),
( 'Arjun', 'Verma', 'arjun@example.com', 1, 1, '2345678901', '8765432109', 'India', '1991-02-02', '2011-02-02', 'Mysore', 90000.00),
('Nihir', 'A', 'nihir@example.com', 1, 1, '3456789012', '7654321098', 'India', '1992-03-03', '2012-03-03', 'Mysore', 70000.00),
('Sohail', 'Z', 'sohail@example.com', 3, 2, '4567890123', '6543210987', 'India', '1993-04-04', '2013-04-04', 'Mysore', 65000.00),
('Ravi', 'R', 'ravi@example.com', 3, 2, '5678901234', '5432109876', 'India', '1994-05-05', '2014-05-05', 'Mysore', 55000.00);

--1
SELECT *FROM Employee_Details
WHERE Department_Code IN (SELECT Department_ID FROM Department_Masters WHERE Department_Name LIKE 'M%g');


--2
UPDATE Employee_Details
SET Salary = Salary * 1.05
WHERE Dateofjoining  >  1/1/2008; 


--3
CREATE TABLE Another_Employee_Details(Staff_ID INT  PRIMARY KEY,FirstName VARCHAR(50),LastName VARCHAR(50),Mail_ID VARCHAR(100),
ReportingTo INT,Department_Code INT ,Phone VARCHAR(50),Mobile_Number VARCHAR(50),Employed_Country VARCHAR(50),DateofBirth DATETIME,
Dateofjoining DATETIME,City VARCHAR(50),Salary NUMERIC(10,2) FOREIGN KEY(Department_Code) REFERENCES Department_Masters(Department_ID));

SELECT *FROM Another_Employee_Details;

INSERT INTO Another_Employee_Details
(Staff_ID ,FirstName,LastName,Mail_ID,ReportingTo,Department_Code,Phone,Mobile_Number,
Employed_Country,DateofBirth,Dateofjoining,City,Salary) 
 SELECT *FROM Employee_Details;

--4
SELECT *FROM Employee_Details
WHERE Salary >(SELECT MAX(Salary) FROM Employee_Details WHERE  Department_code = (SELECT Department_ID FROM Department_Masters WHERE Department_Name = 'Marketing'));


--5
SELECT DM.Department_Code, DM.Department_Name,
AVG(ED.Salary) AS "Average Salary"
From  Department_Masters AS DM
INNER JOIN Employee_Details ED
ON DM.Department_ID = ED.Department_Code
GROUP BY DM.Department_Code,DM.Department_Name ;


--6
SELECT Staff_ID, FirstName, LastName, Salary FROM Employee_Details
WHERE Salary IN (SELECT MAX(Salary) AS "Maximum salary"  FROM Employee_Details
			    UNION
			   SELECT MIN(Salary) AS "Minimum Salary" FROM Employee_Details);

--7
 SELECT 
    Salary * 0.5 AS " Dearness Allowance",
    Salary * 0.05 AS "Professional_Tax",
    Salary + Salary * 0.5 - Salary * 0.05 AS "Net_Salary"
FROM Employee_Details;

--8

SELECT Department_ID FROM Department_Masters AS D
INNER JOIN Employee_Details AS E ON D.Department_ID = E.Department_Code
GROUP BY Department_ID
HAVING COUNT(Department_ID) > 2;

--9

ALTER TABLE  Department_Masters ALTER COLUMN Department_Name VARCHAR(20);

--10

ALTER TABLE Department_Masters ADD Department_Manager VARCHAR(20);
SELECT *FROM Department_Masters;

--11
ALTER TABLE Department_Masters DROP COLUMN Department_Manager;

--12
UPDATE Employee_Details
SET Salary = Salary+1000
WHERE Dateofjoining BETWEEN  '1/1/2005' AND '1/1/2010';


SELECT *FROM  Employee_Details;

--11
DELETE FROM  Department_Masters WHERE department_Status = 2 ;

UPDATE Department_Masters SET Department_Status = 1
WHERE Department_ID = 4;
SELECT *FROM Department_Masters;


--12
SELECT ED.FirstName AS "Employee Name" , E.FirstName AS "Manager Name"
FROM Employee_Details ED
INNER JOIN Employee_Details  E
ON ED.Staff_id  = E.Reportingto;

SELECT *FROM Employee_Details;
--13


SELECT * FROM Employee_details AS ED
INNER JOIN Department_masterS AS DM
ON ED.Staff_id = DM.Department_id 
WHERE DM.Department_location = ED.City ;

SELECT *FROM Department_Masters;