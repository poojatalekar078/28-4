CREATE PROCEDURE Employees
AS
BEGIN
SELECT *FROM Employee_Details;
END;

EXEC Employees;



