CREATE TABLE User_Details(User_ID INT IDENTITY(1,1) PRIMARY KEY,
UserName VARCHAR(255),User_Type INT);

INSERT INTO User_Details(UserName,User_Type)
VALUES('SAM',1),('MAC',2),('David',2),('John',1);

SELECT *FROM User_Details;

CREATE  TABLE User_Personal_Info (UserInfo_ID  INT IDENTITY(1,1) PRIMARY KEY,
User_ID INT FOREIGN KEY REFERENCES User_Details(User_ID),FirstName VARCHAR(255),
LastName VARCHAR(255),Email_ID VARCHAR(255),DOB DATETIME,
Address_info VARCHAR(MAX),City VARCHAR(MAX),State_info VARCHAR(MAX),
Country VARCHAR(MAX),Salary DECIMAL(18,2),DOJ VARCHAR(MAX));

SELECT * FROM User_Personal_Info;

INSERT INTO User_Personal_Info(User_ID,FirstName ,LastName ,Email_ID ,DOB,Address_info,City,State_info,Country ,Salary,DOJ) VALUES
(1,'Sam','Samuel','sam@gmail.com','1996-04-21','karwar','manglore','Karnataka','India',90000.23,'2010-10-23'), 
(2,'Mac','Jason','mac@gmail.com','1992-10-01','kundapura','Banglore','Karnataka','India',97000.23,'2005-11-19'), 
(3,'David','Johnson','david@gmail.com','1988-04-21','Goa','karwar','Karnataka','India',8000.23,'2007-10-23'), 
(4,'John','Matthew','john@gmail.com','1996-04-21','laxmikanthnagar','Mysuru','Karnataka','India',67200.23,'2012-10-23') ; 



--1
SELECT *FROM User_Details
WHERE User_Type = 1;


--2
UPDATE User_Personal_Info
SET Salary = Salary * 1.05
WHERE DOB  >  1/1/2008; 

SELECT * FROM User_Personal_Info;

--3
CREATE TABLE Another_User_Personal_Info(UserInfo_ID  INT  PRIMARY KEY,User_ID INT FOREIGN KEY REFERENCES User_Details(User_ID),FirstName VARCHAR(255),LastName VARCHAR(255),Email_ID VARCHAR(255),DOB DATETIME,
Address_info VARCHAR(MAX),City VARCHAR(MAX),State_info VARCHAR(MAX),Country VARCHAR(MAX),Salary DECIMAL(18,2),DOJ VARCHAR(MAX));


INSERT INTO Another_User_Personal_Info(UserInfo_ID ,User_ID,FirstName ,
LastName ,Email_ID ,DOB,Address_info,City,State_info,Country ,Salary,DOJ) 
SELECT *FROM User_Personal_Info;

SELECT *FROM Another_User_Personal_Info;


--4
SELECT * FROM User_Personal_Info WHERE Salary > (SELECT MAX(Salary) FROM User_Personal_Info 
WHERE User_Id IN (SELECT User_ID FROM User_details WHERE User_type = 1));

SELECT *FROM User_Personal_Info;
SELECT *FROM User_Details;


---5
SELECT UD.User_Type,
AVG(UPI.Salary) AS "Average Salary"
From  User_Details AS UD
INNER JOIN User_Personal_Info AS UPI 
ON  UD.User_ID = UPI.User_ID
GROUP BY UD.User_Type;

SELECT *FROM User_Personal_Info;
SELECT *FROM User_Details;

--6
SELECT UserInfo_ID, FirstName, LastName, Salary FROM  User_Personal_Info
WHERE Salary IN ((SELECT MAX(Salary) AS "Maximum salary"  FROM  User_Personal_Info
                  UNION
			      SELECT MIN(Salary) AS "Minimum Salary" FROM  User_Personal_Info));

SELECT *FROM User_Personal_Info;

--7

SELECT 
    Salary * 0.5 AS DA,
    Salary * 0.05 AS Professional_Tax,
    Salary + Salary * 0.5 - Salary * 0.05 AS Net_Salary
FROM User_Personal_Info;


--8
ALTER TABLE  User_Details ALTER COLUMN UserName VARCHAR(20);

--9
ALTER TABLE User_Personal_Info ADD Age INT;

SELECT *FROM User_Personal_Info;

--10

ALTER TABLE  User_Personal_Info ADD User_Status VARCHAR(10);
SELECT *FROM User_Personal_Info;
ALTER TABLE  User_Personal_Info DROP COLUMN User_Status;


--11
UPDATE User_Personal_Info 
SET Age = DATEDIFF(YEAR, DOB, GETDATE());


SELECT *FROM User_Personal_Info;


--12
 
DELETE FROM User_Personal_Info WHERE User_Status = 2;

