--1
CREATE PROCEDURE All_Users
AS
BEGIN
SELECT *FROM User_details; 
END;

EXEC  All_Users;

--2
CREATE PROCEDURE All_UserPersonalInfo
AS
BEGIN
SELECT *FROM User_Personal_Info;
END;

EXEC  All_UserPersonalInfo;


---3

CREATE PROCEDURE New_User @UserName VARCHAR(255), @User_Type  INT
AS
BEGIN
INSERT INTO  User_details
(UserName,User_Type )values
( @UserName, @User_Type );
END;

EXEC  New_User 'Punnu', 2;

SELECT *FROM User_details; 

--4

CREATE PROCEDURE NewP
    @User_ID  INT , 
    @FirstName VARCHAR(255), 
    @LastName VARCHAR(255), 
    @Email_Id VARCHAR(255), 
    @DOB DATETIME, 
    @Address_info VARCHAR(MAX), 
    @City VARCHAR(MAX), 
    @State_info VARCHAR(MAX), 
    @Country VARCHAR(MAX), 
    @Salary DECIMAL(18,2), 
    @DOJ DATETIME
AS
BEGIN
    DECLARE @User_Personal_Info INT; 

    INSERT INTO User_Personal_Info (User_Id, FirstName, LastName, Email_Id, DOB, Address_info, City, State_info, Country, Salary, DOJ)
    VALUES (@User_Id, @FirstName, @LastName, @Email_Id, @DOB, @Address_info, @City, @State_info, @Country, @Salary, @DOJ);

    SET @User_Personal_Info = SCOPE_IDENTITY();
END;

EXEC NewP 5,'Pooja','Talekar','pooja@gmail.com','2001-03-22','karwar','Karwar','Karnataka','india',90000,'2024-12-23';

SELECT *FROM User_Personal_Info;


--5

CREATE PROCEDURE Update_NewPer
    @UserInfo_ID INT,
    @User_ID  INT , 
    @FirstName VARCHAR(255), 
    @LastName VARCHAR(255), 
    @Email_Id VARCHAR(255), 
    @DOB DATETIME, 
    @Address_info VARCHAR(MAX), 
    @City VARCHAR(MAX), 
    @State_info VARCHAR(MAX), 
    @Country VARCHAR(MAX), 
    @Salary DECIMAL(18,2), 
    @DOJ DATETIME             
	AS
UPDATE  User_Personal_Info  SET 
FirstName=@FirstName,LastName=@LastName,Email_Id=@Email_Id,DOB=@DOB,Address_info =@Address_info,City=@City,State_info=@State_info,Country = @Country,Salary=@Salary,
DOJ=@DOJ ,  @User_ID = @User_ID Where UserInfo_ID = @UserInfo_ID;


EXEC Update_NewPer   5,3,'Poonam','Talekar','poonam80@.com','2001-05-29','karwar','kawrar','karnataka','india',4599,'2023-02-01'; 


 SELECT *FROM User_Personal_Info;

 


 --6 

CREATE PROCEDURE UserPersonalInfo
AS 
SELECT FirstName AS "User Name",
DATEDIFF(YEAR, DOB, GETDATE())
AS "Years of experience"
FROM User_Personal_Info;


EXEC  UserPersonalInfo;

