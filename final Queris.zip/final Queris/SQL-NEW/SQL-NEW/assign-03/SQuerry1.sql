

CREATE TABLE Products(Product_ID INT PRIMARY KEY IDENTITY(1,1) ,Product_Code VARCHAR(10),Product_Name VARCHAR(255),Product_Desc VARCHAR(255),Manufacturer VARCHAR(255),
Unit_Price DECIMAL (9,2),Units_In_Stock INT);


SELECT *FROM Products;


CREATE TABLE Customers(Customer_ID INT PRIMARY KEY IDENTITY(1,1),Customer_Name VARCHAR(255),Customer_Address VARCHAR(255),Contact_Number VARCHAR(255),Company_Name VARCHAR(255));



CREATE TABLE Orders (Orders_ID INT PRIMARY KEY IDENTITY(1,1), Customer_ID INT FOREIGN KEY(Customer_ID) REFERENCES Customers(Customer_ID),Product_ID INT FOREIGN KEY(Product_ID)
REFERENCES Products(Product_ID),Units_Ordered INT,Order_Date DateTime);

SELECT *FROM Orders;
SELECT *FROM Customers;


INSERT INTO Products(Product_Code,Product_Name, Product_Desc, ManufactureR, Unit_Price, Units_IN_Stock) VALUES 
('pc001','toothpaste','Colgate-Palmolive','Hindustan Lever Limited',100.00,20), 
('pc002','coffee','arabica beans','Hindustan Lever Limited',400.34,60), 
('pc003','laptop','fast processing laptop','Dell',9999,2000), 
('pc004','smartwatch','fitness tracker','Apple',94.46,200), 
('pc005','shampoo','nourishing shampoo','Skincare',30,220); 


INSERT INTO Customers(Customer_Name, Customer_Address, Contact_Number, Company_name) VALUES  
('Alice', 'New York', '1234567890', 'Corp Ltd'), 
('Bob', 'Los Angeles', '9876543210', 'Tech Solutions'), 
('Carol', 'Chicago', '5555555555', 'ABC Corporation'), 
('David', 'Houston', '7777777777', 'XYZ Enterprises'), 
('Eve', 'San Francisco', '9999999999', 'Innovate Ltd');

SELECT *FROM Customers;




INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,3,5,'2024-04-04'), 
(1,2,3,'2024-03-30'), 
(2,1,10,'2024-03-21'), 
(3,3,1,'2024-04-03'), 
(4,3,1,'2024-03-12'), 
(5,4,5,'2024-03-04'), 
(1,3,4,'2024-04-02'), 
(1,2,5,'2024-04-04'); 
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(3,5,1,'2024-04-04'), 
(2,1,5,'2024-03-30'), 
(1,2,3,'2024-03-21');
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,5,1,'2024-04-04'), 
(1,1,5,'2024-03-30'), 
(1,2,3,'2024-03-21'),
(1,3,4,'2024-04-02'), 
(1,2,5,'2024-04-04'); 
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,2,5,'2024-04-04'); 
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,3,5,'2024-04-04'), 
(1,2,3,'2024-03-30'), 
(2,1,10,'2024-03-21'), 
(3,3,1,'2024-04-03'), 
(4,3,1,'2024-03-12'), 
(5,4,5,'2024-03-04'), 
(1,3,4,'2024-04-02'), 
(1,2,5,'2024-04-04'); 
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(3,5,1,'2024-04-04'), 
(2,1,5,'2024-03-30'), 
(1,2,3,'2024-03-21');
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,5,1,'2024-04-04'), 
(1,1,5,'2024-03-30'), 
(1,2,3,'2024-03-21'),
(1,3,4,'2024-04-02'), 
(1,2,5,'2024-04-04'); 
INSERT INTO Orders(Customer_id, Product_id, Units_ordered, Order_date) VALUES
(1,2,5,'2024-04-04');


SELECT *FROM Orders;

--1
SELECT *FROM Products;

--2
SELECT *FROM Products WHERE ManufactureR = 'Hindustan Lever Limited';


--3
SELECT
    Product_Name,
    Customer_Name,
    Company_Name,
    Order_Date
FROM
    Orders
    INNER JOIN Customers ON Orders.Customer_ID = Customers.Customer_ID
    INNER JOIN Products ON Orders.Product_ID = Products.Product_ID
WHERE
    Order_Date > DATEADD(month, -1, GETDATE());



SELECT *FROM Products;
SELECT *FROM Customers;
SELECT *FROM Orders;

--4
SELECT
    C.Customer_Name,
    COUNT(O.Orders_ID) AS "Order count"
FROM
    Customers AS C
INNER JOIN Orders AS O 
ON C.Customer_ID = O.Customer_ID
GROUP BY
    C.Customer_Name
HAVING
    COUNT(O.Orders_ID) > 10;

SELECT *FROM Orders;
SELECT *FROM Customers;


---5
CREATE TABLE Another_Products(Product_name VARCHAR(255),Customer_Name VARCHAR(255),Company_Name VARCHAR(255),Order_Date DATETIME);

INSERT INTO Another_Products(Product_name,Customer_name,Company_name,Order_date)
SELECT P.Product_name,C.customer_name,C.company_name ,O.order_date
FROM Orders AS O
INNER JOIN Products AS P ON
O.Product_ID = P.Product_ID
INNER JOIN Customers AS C
ON  O.Customer_ID = C.Customer_ID;

SELECT *FROM Products;
SELECT *FROM Customers;
SELECT *FROM Orders;

--6
SELECT Avg(Unit_Price) AS "Average price"
FROM Products
WHERE Manufacturer = 'Hindustan Lever Limited';

SELECT *FROM Products;

--7

SELECT 
MAX(Unit_Price) AS "Maximum unit price",
MAX(Unit_Price)AS "Minimum unit price"
FROM Products
WHERE  Manufacturer = 'Hindustan Lever Limited';

SELECT *FROM Products;

--8
ALTER TABLE Orders Add Total_Price INT;


SELECT *FROM Orders;

--9


UPDATE Orders
SET Total_Price = P.Unit_price * O.Units_ordered
FROM Orders AS O
INNER JOIN Products AS P
ON O.Product_ID = P.Product_ID;
 
SELECT *FROM Orders;
SELECT *FROM Products;


 --10
 ALTER TABLE Orders DROP COLUMN Total_Price;
 SELECT *FROM Orders;
 --11
 DELETE FROM Products WHERE Units_In_Stock = 0;

 SELECT *FROM Products;
 ---12

ALTER TABLE Customers ALTER COLUMN Company_Name VARCHAR(125);


--13
SELECT 
    C.Customer_name, 
    C.Company_name, 
    SUM(P.Unit_price * O.Units_ordered) AS "Total_Order_Amount"
FROM 
    Customers C
INNER JOIN 
    Orders O ON C.Customer_ID = O.Customer_ID
INNER JOIN 
    Products P ON O.Product_ID = P.Product_ID
GROUP BY 
    C.Customer_name, 
    C.Company_name
HAVING 
    SUM(P.Unit_price * O.Units_ordered) < 5000;

SELECT *FROM Customers;
SELECT *FROM Orders;
SELECT *FROM Products;
--14

SELECT 
    C.Customer_name,
    COUNT(O.Orders_Id) AS "Total orders"
FROM 
    Customers AS  C
INNER JOIN 
    Orders AS O 
ON C.Customer_ID = O.Customer_ID
GROUP BY 
   C.Customer_name;


SELECT *FROM Customers;
SELECT *FROM Orders;

--sp

--1
SELECT  P.Product_Name, C.Customer_Name, C.Company_Name, O.Order_Date
FROM Customers AS C
INNER JOIN Orders AS O
ON C.Customer_ID = O.Customer_ID
INNER JOIN Products AS P
ON P.Product_ID=O.Product_ID
GROUP BY  P.Product_Name, C.Customer_Name, C.Company_Name, O.Order_Date;


SELECT *FROM Customers;
SELECT *FROM Orders;
SELECT *FROM Products;

--2
CREATE PROCEDURE InsertOrders
@customer_ID INT,
@Product_ID INT,
@Units_ordered INT,
@Order_Date DATETIME
AS
BEGIN
    INSERT INTO Orders (Customer_ID, Product_ID,Units_Ordered, Order_date)
    VALUES (@Customer_ID, @Product_ID, @Units_ordered, @Order_Date);
END;

EXEC InsertOrders @Customer_ID = 5, @Product_ID = 2, @Units_ordered= 8, @Order_Date= '2001-12-31';

SELECT *FROM Orders;

--3
CREATE PROCEDURE UpdateProducts
    @Product_ID INT,
    @Units_In_stock INT
AS
BEGIN
    UPDATE Products
    SET Units_in_stock = @units_In_stock
    WHERE Product_ID = @Product_ID
END;

EXEC  UpdateProducts @units_In_stock = 90, @Product_ID = 5;

SELECT *FROM Products;
--4
--d--
CREATE PROCEDURE Update_Unitprices
  @Product_ID INT 
AS  
BEGIN 
    DECLARE @Units_In_stock INT; 
    DECLARE @Unit_Price DECIMAL(10,2); 
    DECLARE @New_Unit_Price DECIMAL(10,2); 

    SELECT
	@Units_In_stock = Units_In_stock,
	@Unit_Price = Unit_Price 
    FROM Products
    WHERE Product_ID = @Product_ID; 

    IF @Units_In_stock > 1000 
        SET @New_Unit_price = @Unit_price - (@Unit_price * 0.10); 
    ELSE 
        SET @New_Unit_price = @Unit_price - (@Unit_price * 0.05); 

     UPDATE Products
    SET Unit_Price = @New_Unit_price 
    WHERE Product_ID = @Product_ID; 
END;

EXEC Update_Unitprices @Product_Id = 1;


SELECT *FROM Products;







